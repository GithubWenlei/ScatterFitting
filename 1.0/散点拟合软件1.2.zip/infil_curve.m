clear all;
%syms f m t a1 a2 b1 b2 c1 c2 d1 d2;
a=	369.7102079;	b=	-72.54903603;	c=	1.838828087;	d=	1;
e=	-0.2836364;	f=	0.6646548;	g=	-0.5095829;	h=	0.145;
t0=1;t2=300;
syms t y
t=1:300;
y=1:300;
for j=1:300
    if t(j)==t0
        x=0;y(1,j)=e*x^3+f*x^2+g*x+h;
    elseif t(j)==t2
        x=1;y(1,j)=e*x^3+f*x^2+g*x+h;
    else
A=[a b c d-t(j)];
S=roots(A);
for i =1:3
    x=S(i);
    ISR=isreal(x);
   if x>=0 & 1 >=x & ISR==1     
       y(1,j)=e*x^3+f*x^2+g*x+h;
   end
end
    end
end
subplot(1,2,1)
plot(t,y);
% dta =csvread('data.csv');
% subplot(1,2,2)
% plot(dta(:,1),dta(:,2));

